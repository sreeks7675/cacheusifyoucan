"""TruthLens Sentinel — data contracts.

Input : InvestigationResult      (from the EXISTING pipeline — read-only)
Output: ThreatIntelligenceResult (consumed by the dashboard)

The key design idea: Sentinel never re-analyzes media. It inherits the main
pipeline's learned artifacts (perceptual hash, CLIP embedding, generator
fingerprint, extracted entities) and uses them as SEARCH KEYS on the internet.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Optional, Callable
import time
import uuid


# ---------------------------------------------------------------- INPUT ----
@dataclass
class InvestigationResult:
    """What the existing Investigation/Decision agents already emit."""
    case_id: str
    prediction: str                      # "FAKE" | "AUTHENTIC" | "SUSPICIOUS"
    confidence: float                    # 0..1
    media_type: str                      # "image"
    media_hash: str                      # SHA-256 of the exhibit
    timestamp: float
    metadata: dict[str, Any] = field(default_factory=dict)
    extracted_entities: list[str] = field(default_factory=list)   # names, orgs, domains
    explainability: dict[str, Any] = field(default_factory=dict)
    forensic_evidence: dict[str, Any] = field(default_factory=dict)
    investigation_summary: str = ""
    review_status: str = "auto"

    # --- artifacts Sentinel inherits (produced by main-app agents) ---
    # forensic_evidence is expected to carry:
    #   "phash":                 64-bit perceptual hash hex (Forensic Agent)
    #   "clip_embedding":        list[float] 512/768-d      (Semantic Agent)
    #   "generator_fingerprint": list[float] latent-decoder signature (Forensic Agent)
    #   "generator_family":      e.g. "diffusion"
    @classmethod
    def from_dict(cls, d: dict) -> "InvestigationResult":
        known = {f: d[f] for f in cls.__dataclass_fields__ if f in d}
        return cls(**known)


@dataclass
class SearchKeys:
    """Derived ONLY from main-app outputs — this is the knowledge reuse."""
    phash: Optional[str]                       # perceptual hash of exhibit
    clip_embedding: Optional[list[float]]      # semantic embedding
    generator_fingerprint: Optional[list[float]]
    generator_family: Optional[str]
    entity_keywords: list[str]                 # from extracted_entities
    source: dict[str, str] = field(default_factory=lambda: {
        "phash": "Forensic Agent · exhibit preprocessing",
        "clip_embedding": "Semantic Agent · ChromaDB scene embeddings",
        "generator_fingerprint": "Forensic Agent · ChromaDB artifact fingerprints",
        "entity_keywords": "Planner Agent · entity extraction",
    })


# --------------------------------------------------------------- OUTPUT ----
@dataclass
class MatchEvidence:
    """WHY we say a crawled item is the same fake — the judging basis."""
    method: str            # "reverse_image" | "keyword" | "platform_crawl"
    provider: str          # e.g. "SearchProvider:google_images"
    query_used: str        # human-readable description of the query
    phash_distance: Optional[int]      # Hamming distance /64 (<=8 => near-copy)
    clip_cosine: Optional[float]       # semantic similarity 0..1
    fingerprint_match: Optional[bool]  # same generator toolchain?
    classification: str    # "exact_copy" | "variant" | "unrelated"


@dataclass
class CrawlMatch:
    url: str
    platform: str
    handle: str
    status: str                       # "live" | "removed"
    first_seen: Optional[str]
    views: Optional[str]
    region: Optional[str]
    thumbnail_sha256: Optional[str]
    evidence: MatchEvidence = None


@dataclass
class ThreatIntelligenceResult:
    case_id: str
    search_keys_used: dict = field(default_factory=dict)     # SearchKeys, serialized (embeddings truncated)
    overall_threat_score: float = 0.0                        # 0..10
    campaign_detected: bool = False
    campaign_id: Optional[str] = None
    related_cases: list[dict] = field(default_factory=list)
    crawl_matches: list[dict] = field(default_factory=list)  # CrawlMatch, serialized
    knowledge_graph: dict = field(default_factory=lambda: {"nodes": [], "edges": []})
    human_review_required: bool = False
    generated_reports: list[dict] = field(default_factory=list)
    monitoring_status: dict = field(default_factory=dict)
    cybercrime_package: dict = field(default_factory=dict)   # full pre-filing preview, see pipeline
    recommendations: list[str] = field(default_factory=list)
    dashboard_payload: dict = field(default_factory=dict)
    audit_logs: list[dict] = field(default_factory=list)

    def log(self, agent: str, message: str, ok: bool = True) -> None:
        self.audit_logs.append({
            "id": uuid.uuid4().hex[:8], "ts": time.time(),
            "agent": agent, "message": message, "ok": ok,
        })

    def to_dict(self) -> dict:
        return asdict(self)
