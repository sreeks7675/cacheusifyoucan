"""Sentinel pipeline — 8 agents, failure-tolerant, fully audited.

Threat Intelligence → Internet Intelligence → Correlation → Knowledge Graph
→ Threat Score → Human Review (gate) → Cybercrime Report → Monitoring

Runs under LangGraph when installed; otherwise a plain async sequence with the
exact same node functions (hackathon insurance). Any node may fail — the
workflow continues and the failure is written to audit_logs. The main
TruthLens pipeline is never broken.
"""
from __future__ import annotations
from dataclasses import asdict
import time

from .schemas import InvestigationResult, ThreatIntelligenceResult, CrawlMatch
from .adapters import ProviderRegistry
from .matching import EvidenceMatcher, derive_search_keys

THREAT_HITL_THRESHOLD = 7.0


class SentinelPipeline:
    def __init__(self, registry: ProviderRegistry, matcher: EvidenceMatcher,
                 case_store=None):
        """case_store: the main app's ChromaDB collection of past-case
        embeddings — correlation queries the SAME store the Retrieval agent
        uses, so Sentinel inherits every case the platform has ever seen."""
        self.reg = registry
        self.matcher = matcher
        self.case_store = case_store

    # ------------------------------------------------------------ nodes ----
    async def threat_intelligence(self, inv, keys, out):
        try:
            hits = await self.reg.threat_feed.lookup(keys.entity_keywords)
            out.dashboard_payload["threat_feed_hits"] = hits
            out.log("Threat Intelligence",
                    f"{len(hits)} extracted entities matched threat feeds via {self.reg.threat_feed.name}.")
        except Exception as e:
            out.log("Threat Intelligence", f"feed lookup failed ({e}) — continuing.", ok=False)

    async def internet_intelligence(self, inv, keys, out):
        """The crawl. Search keys come FROM the main app; every candidate is
        judged by EvidenceMatcher; every match records its evidence basis."""
        matches: list[CrawlMatch] = []
        for provider in self.reg.search:
            try:
                cands = await provider.reverse_image(keys.phash, keys.clip_embedding)
                for c in cands:
                    ev = self.matcher.judge(keys, c, "reverse_image", provider.name,
                                            f"pHash {keys.phash[:8]}… + CLIP embedding")
                    if ev.classification != "unrelated":
                        matches.append(_to_match(c, ev))
                if keys.entity_keywords:
                    for c in await provider.keyword(keys.entity_keywords):
                        ev = self.matcher.judge(keys, c, "keyword", provider.name,
                                                " ".join(keys.entity_keywords[:4]))
                        matches.append(_to_match(c, ev))
            except Exception as e:
                out.log("Internet Intelligence",
                        f"{provider.name} failed ({e}) — degrading gracefully.", ok=False)
        for crawler in self.reg.crawlers:
            try:
                for c in await crawler.crawl(keys):
                    ev = self.matcher.judge(keys, c, "platform_crawl", crawler.name,
                                            "watchlist channels · image hash sweep")
                    if ev.classification != "unrelated":
                        matches.append(_to_match(c, ev))
            except Exception as e:
                out.log("Internet Intelligence",
                        f"{crawler.name} failed ({e}) — degrading gracefully.", ok=False)
        out.crawl_matches = [asdict(m) for m in matches]
        live = sum(1 for m in matches if m.status == "live")
        out.log("Internet Intelligence",
                f"{len(matches)} matches across {len(self.reg.search) + len(self.reg.crawlers)} providers "
                f"({live} live). Basis recorded per match: pHash Δ, CLIP cosine, fingerprint.")

    async def correlation(self, inv, keys, out):
        try:
            related = []
            if self.case_store is not None and keys.generator_fingerprint:
                # SAME ChromaDB collection the main app's Retrieval agent uses.
                res = self.case_store.query(
                    query_embeddings=[keys.generator_fingerprint], n_results=3)
                for cid, dist in zip(res["ids"][0], res["distances"][0]):
                    if cid != inv.case_id and dist < 0.25:
                        related.append({"case_id": cid, "fingerprint_distance": round(dist, 3)})
            else:  # demo fallback
                related = [{"case_id": "TL-2026-0329", "fingerprint_distance": 0.11}]
            out.related_cases = related
            out.campaign_detected = bool(related)
            if related:
                out.campaign_id = "CAMP-2026-017"
            out.log("Correlation",
                    f"Generator fingerprint queried against main-app case store → "
                    f"{len(related)} related case(s); campaign={out.campaign_id}.")
        except Exception as e:
            out.log("Correlation", f"failed ({e}) — continuing.", ok=False)

    async def knowledge_graph(self, inv, keys, out):
        nodes = [{"id": inv.case_id, "type": "case"}]
        edges = []
        for m in out.crawl_matches:
            nodes.append({"id": m["url"], "type": "distribution", "platform": m["platform"]})
            edges.append({"from": inv.case_id, "to": m["url"],
                          "basis": m["evidence"]["classification"]})
        for r in out.related_cases:
            nodes.append({"id": r["case_id"], "type": "case"})
            edges.append({"from": inv.case_id, "to": r["case_id"], "basis": "generator_fingerprint"})
        out.knowledge_graph = {"nodes": nodes, "edges": edges}
        out.log("Knowledge Graph", f"+{len(nodes)-1} nodes, +{len(edges)} edges.")

    async def threat_score(self, inv, keys, out):
        live = sum(1 for m in out.crawl_matches if m["status"] == "live")
        score = min(10.0, inv.confidence * 5          # how sure the fake is
                    + live * 1.0                       # active distribution
                    + (2.0 if out.campaign_detected else 0)
                    + (1.0 if out.dashboard_payload.get("threat_feed_hits") else 0))
        out.overall_threat_score = round(score, 1)
        out.log("Threat Score",
                f"{out.overall_threat_score}/10 = confidence×5 + live_hosts + campaign + feed_hits.")

    async def human_review(self, inv, keys, out):
        out.human_review_required = out.overall_threat_score >= THREAT_HITL_THRESHOLD
        out.cybercrime_package = self._build_package_preview(inv, out)
        out.log("Human Review",
                "Threat ≥ 7.0 policy — package preview built, routed to analyst queue."
                if out.human_review_required else "Below HITL threshold — informational only.")

    async def cybercrime_report(self, inv, keys, out, approved: bool = False):
        """Only executes the FILING after HITL approval; preview always exists."""
        if not approved:
            out.log("Cybercrime Report", "Awaiting analyst approval — nothing filed.")
            return
        try:
            receipt = await self.reg.cybercrime.file_complaint(out.cybercrime_package)
            out.cybercrime_package["status"] = "filed"
            out.cybercrime_package["receipt"] = receipt
            out.generated_reports.append(receipt)
            out.log("Cybercrime Report",
                    f"Filed via {self.reg.cybercrime.name} — ack {receipt['acknowledgment']}.")
        except Exception as e:
            out.cybercrime_package["status"] = "filing_failed"
            out.log("Cybercrime Report", f"filing failed ({e}) — partial result returned.", ok=False)

    async def monitoring(self, inv, keys, out):
        out.monitoring_status = {
            "watch_phash": keys.phash, "recrawl_interval_h": 24,
            "takedown_requests": [m["url"] for m in out.crawl_matches if m["status"] == "live"],
        }
        out.log("Continuous Monitoring",
                f"pHash enrolled for 24h re-crawl; takedowns dispatched to "
                f"{len(out.monitoring_status['takedown_requests'])} live hosts.")

    # ----------------------------------------------- the filing preview ----
    def _build_package_preview(self, inv, out) -> dict:
        """Everything the analyst sees BEFORE approving. Answers: which
        website, what observations, on what basis."""
        return {
            "status": "pending_hitl",
            "complaint": {
                "category": "Online financial fraud — synthetic media",
                "case_reference": inv.case_id,
                "narrative": inv.investigation_summary,
                "original_verdict": {"prediction": inv.prediction, "confidence": inv.confidence},
            },
            "observations": [
                {
                    "url": m["url"], "platform": m["platform"], "status": m["status"],
                    "first_seen": m["first_seen"], "thumbnail_sha256": m["thumbnail_sha256"],
                    "basis": {
                        "found_via": f'{m["evidence"]["method"]} ({m["evidence"]["provider"]})',
                        "query": m["evidence"]["query_used"],
                        "phash_distance": m["evidence"]["phash_distance"],
                        "clip_cosine": m["evidence"]["clip_cosine"],
                        "generator_fingerprint_match": m["evidence"]["fingerprint_match"],
                        "classification": m["evidence"]["classification"],
                    },
                } for m in out.crawl_matches
            ],
            "attachments": [
                "forensic_report.pdf (signed, TL-PROD-03)",
                "evidence_hashes.json (SHA-256, chain of custody)",
                "knowledge_graph.json",
                "takedown_url_list.txt",
            ],
        }


def _to_match(c: dict, ev) -> CrawlMatch:
    return CrawlMatch(
        url=c["url"], platform=c["platform"], handle=c.get("handle", ""),
        status=c.get("status", "live"), first_seen=c.get("first_seen"),
        views=c.get("views"), region=c.get("region"),
        thumbnail_sha256=c.get("thumbnail_sha256"), evidence=ev,
    )
