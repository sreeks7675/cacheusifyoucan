"""Complaint Management — the workflow does NOT stop at filing.
Searchable store of complaint records with status lifecycle and history.
New portals plug in as CyberCrimeProvider adapters; this store is portal-agnostic."""
from __future__ import annotations
import time, uuid

STATUSES = ["draft", "pending_hitl", "filed", "acknowledged", "under_investigation",
            "action_taken", "closed", "rejected"]

class ComplaintStore:
    def __init__(self, audit=None):
        self.records: dict[str, dict] = {}
        self.audit = audit

    def create(self, case_id: str, package: dict, portal: str) -> dict:
        cid = "CMP-" + uuid.uuid4().hex[:8].upper()
        rec = {
            "complaint_id": cid, "case_id": case_id, "status": "pending_hitl",
            "portal": portal, "portal_name": portal.split(":")[-1].upper(),
            "submitted_at": None, "acknowledgment": None,
            "assigned_officer": None, "jurisdiction": "Cyber Cell — Punjab",
            "package": package, "notes": [],
            "history": [{"ts": time.time(), "status": "pending_hitl", "by": "sentinel"}],
            "last_updated": time.time(),
        }
        self.records[cid] = rec
        return rec

    def transition(self, cid: str, status: str, by: str, note: str = "", **fields):
        rec = self.records[cid]
        rec["status"] = status
        rec.update(fields)
        rec["history"].append({"ts": time.time(), "status": status, "by": by, "note": note})
        rec["last_updated"] = time.time()
        if self.audit: self.audit.log("complaint_" + status, by, f"{cid} {note}")
        return rec

    def mark_filed(self, cid: str, receipt: dict, by: str):
        return self.transition(cid, "filed", by, submitted_at=time.time(),
                               acknowledgment=receipt.get("acknowledgment"))

    def add_note(self, cid: str, by: str, text: str):
        self.records[cid]["notes"].append({"ts": time.time(), "by": by, "text": text})

    def search(self, q: str = "", status: str = None) -> list[dict]:
        q = q.lower()
        return [r for r in self.records.values()
                if (status is None or r["status"] == status)
                and (q in r["complaint_id"].lower() or q in r["case_id"].lower())]
