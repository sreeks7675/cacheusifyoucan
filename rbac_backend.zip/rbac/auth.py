"""JWT auth + session management. Uses PyJWT when available; otherwise a
compact HS256 implementation (same wire format) so the demo never breaks."""
from __future__ import annotations
import base64, hashlib, hmac, json, time, uuid
from .models import User, Session, hash_password

SECRET = "change-me-in-prod"
ACCESS_TTL = 60 * 60           # 1 h
REMEMBER_TTL = 60 * 60 * 24 * 30

def _b64(d: bytes) -> str: return base64.urlsafe_b64encode(d).rstrip(b"=").decode()
def _unb64(s: str) -> bytes: return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))

def jwt_encode(payload: dict) -> str:
    try:
        import jwt
        return jwt.encode(payload, SECRET, algorithm="HS256")
    except ImportError:
        header = _b64(json.dumps({"alg": "HS256", "typ": "JWT"}).encode())
        body = _b64(json.dumps(payload).encode())
        sig = _b64(hmac.new(SECRET.encode(), f"{header}.{body}".encode(), hashlib.sha256).digest())
        return f"{header}.{body}.{sig}"

def jwt_decode(token: str) -> dict:
    try:
        import jwt
        return jwt.decode(token, SECRET, algorithms=["HS256"])
    except ImportError:
        header, body, sig = token.split(".")
        want = _b64(hmac.new(SECRET.encode(), f"{header}.{body}".encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(sig, want):
            raise ValueError("bad signature")
        payload = json.loads(_unb64(body))
        if payload.get("exp", 0) < time.time():
            raise ValueError("expired")
        return payload

class AuthService:
    MAX_FAILED = 5

    def __init__(self, store, audit):
        self.store = store          # RbacStore
        self.audit = audit          # AuditLog
        self.sessions: dict[str, Session] = {}

    def login(self, username: str, password: str, remember: bool = False, ip: str = "-") -> Session:
        u = self.store.users.get(username)
        if not u or not u.enabled or u.locked:
            self.audit.log("failed_login", username, f"disabled/locked/unknown from {ip}")
            raise PermissionError("invalid credentials")
        if u.password_hash != hash_password(password):
            u.failed_attempts += 1
            if u.failed_attempts >= self.MAX_FAILED:
                u.locked = True
                self.audit.log("account_locked", username, "too many failures")
            self.audit.log("failed_login", username, f"bad password from {ip}")
            raise PermissionError("invalid credentials")
        u.failed_attempts = 0
        ttl = REMEMBER_TTL if remember else ACCESS_TTL
        now = time.time()
        token = jwt_encode({"sub": username, "role": u.role, "iat": int(now),
                            "exp": int(now + ttl), "jti": uuid.uuid4().hex})
        s = Session(token, username, u.role, now, now + ttl, remember)
        self.sessions[token] = s
        u.login_history.append({"ts": now, "ip": ip, "ok": True})
        self.audit.log("login", username, f"role={u.role} remember={remember}")
        return s

    def logout(self, token: str):
        s = self.sessions.pop(token, None)
        if s: self.audit.log("logout", s.username, "")

    def verify(self, token: str) -> dict:
        payload = jwt_decode(token)
        if token not in self.sessions:
            raise PermissionError("session revoked")
        return payload

    def reset_password(self, admin: str, username: str, new_pw: str):
        u = self.store.users[username]
        u.password_hash = hash_password(new_pw)
        u.locked = False; u.failed_attempts = 0
        self.audit.log("password_reset", admin, f"target={username}")
