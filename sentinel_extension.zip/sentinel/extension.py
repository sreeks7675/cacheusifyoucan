"""TruthLens Sentinel — plug-and-play entry point.

Integration into the existing app is exactly one call:

    from sentinel import ThreatIntelligenceExtension

    sentinel = ThreatIntelligenceExtension(
        fingerprint_matcher=forensic_agent.match_generator_fingerprint,  # reuse training
        clip_embedder=semantic_agent.embed_image,                        # reuse training
        case_store=chroma_client.get_collection("case_fingerprints"),    # reuse memory
    )
    result = await sentinel.analyze(investigation_result)

Or event-driven (preferred):

    event_bus.subscribe("InvestigationCompletedEvent", sentinel.on_investigation_completed)

No existing agent, workflow, or entry point is modified.
"""
from __future__ import annotations
import asyncio
from typing import Callable, Optional

from .schemas import InvestigationResult, ThreatIntelligenceResult
from .adapters import ProviderRegistry
from .matching import EvidenceMatcher, derive_search_keys
from .pipeline import SentinelPipeline


class ThreatIntelligenceExtension:
    def __init__(self,
                 registry: Optional[ProviderRegistry] = None,
                 fingerprint_matcher: Optional[Callable] = None,
                 clip_embedder: Optional[Callable] = None,
                 case_store=None,
                 hitl_callback: Optional[Callable] = None):
        """hitl_callback(package_preview) -> bool : your UI's approve/reject.
        If omitted, analyze() stops at the gate and returns the preview —
        call resume_filing() after the analyst decides."""
        self.registry = registry or ProviderRegistry()
        self.matcher = EvidenceMatcher(fingerprint_matcher, clip_embedder)
        self.pipeline = SentinelPipeline(self.registry, self.matcher, case_store)
        self.hitl_callback = hitl_callback

    # ------------------------------------------------------- single API ----
    async def analyze(self, investigation_result) -> ThreatIntelligenceResult:
        inv = (investigation_result if isinstance(investigation_result, InvestigationResult)
               else InvestigationResult.from_dict(investigation_result))
        out = ThreatIntelligenceResult(case_id=inv.case_id)
        keys = derive_search_keys(inv)
        out.search_keys_used = {
            "phash": keys.phash,
            "clip_embedding_dims": len(keys.clip_embedding or []),
            "generator_fingerprint_dims": len(keys.generator_fingerprint or []),
            "generator_family": keys.generator_family,
            "entity_keywords": keys.entity_keywords,
            "source": keys.source,
        }
        out.log("EventBus", f"InvestigationCompletedEvent — case {inv.case_id} "
                            f"({inv.prediction}, {inv.confidence:.0%}). Search keys inherited from main pipeline.")

        p = self.pipeline
        await p.threat_intelligence(inv, keys, out)
        await p.internet_intelligence(inv, keys, out)
        await p.correlation(inv, keys, out)
        await p.knowledge_graph(inv, keys, out)
        await p.threat_score(inv, keys, out)
        await p.human_review(inv, keys, out)

        approved = False
        if out.human_review_required and self.hitl_callback:
            approved = bool(self.hitl_callback(out.cybercrime_package))
            out.log("Human Review", f"Analyst decision: {'APPROVED' if approved else 'REJECTED'}.")
        await p.cybercrime_report(inv, keys, out, approved=approved)
        await p.monitoring(inv, keys, out)

        out.recommendations = self._recommendations(out)
        out.dashboard_payload.update({
            "threat_score": out.overall_threat_score,
            "campaign": out.campaign_id,
            "live_distribution": sum(1 for m in out.crawl_matches if m["status"] == "live"),
            "package_status": out.cybercrime_package.get("status"),
        })
        return out

    async def resume_filing(self, out: ThreatIntelligenceResult, approved: bool,
                            inv: InvestigationResult) -> ThreatIntelligenceResult:
        """Call after an async HITL decision (e.g. from the UI)."""
        keys = derive_search_keys(inv)
        await self.pipeline.cybercrime_report(inv, keys, out, approved=approved)
        return out

    # ---------------------------------------------------- event adapter ----
    def on_investigation_completed(self, event: dict):
        """Subscribe this to your bus (RabbitMQ/Kafka/Redis Streams consumer
        should call it with the event payload)."""
        return asyncio.get_event_loop().create_task(self.analyze(event["investigation_result"]))

    @staticmethod
    def _recommendations(out) -> list[str]:
        recs = []
        live = [m for m in out.crawl_matches if m["status"] == "live"]
        if live:
            recs.append(f"Issue takedown requests to {len(live)} live host(s).")
        if out.campaign_detected:
            recs.append(f"Merge with campaign {out.campaign_id} for joint filing.")
        if out.human_review_required:
            recs.append("Analyst approval required before external submission (threat ≥ 7.0).")
        recs.append("Keep media hash under 24h re-crawl monitoring.")
        return recs
