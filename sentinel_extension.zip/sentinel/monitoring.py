"""Continuous Monitoring — keeps hunting after the report is generated.
Periodically re-runs the crawl with the same inherited keys; anything new
raises an alert and is appended to the open complaint."""
from __future__ import annotations
import asyncio, time

class ContinuousMonitor:
    def __init__(self, registry, matcher, notifier, complaint_store=None,
                 interval_s: int = 24 * 3600):
        self.reg, self.matcher, self.notifier = registry, matcher, notifier
        self.complaints = complaint_store
        self.interval = interval_s
        self.watches: dict[str, dict] = {}     # case_id -> {keys, seen_urls, complaint_id}
        self._task = None

    def enroll(self, case_id: str, keys, seen_urls: list[str], complaint_id: str = None):
        self.watches[case_id] = {"keys": keys, "seen": set(seen_urls),
                                 "complaint_id": complaint_id, "alerts": []}

    async def sweep_once(self, case_id: str) -> list[dict]:
        w = self.watches[case_id]
        new = []
        for provider in self.reg.search:
            try:
                for c in await provider.reverse_image(w["keys"].phash, w["keys"].clip_embedding):
                    if c["url"] in w["seen"]: continue
                    ev = self.matcher.judge(w["keys"], c, "monitor_recrawl", provider.name,
                                            "24h re-crawl · inherited keys")
                    if ev.classification != "unrelated":
                        w["seen"].add(c["url"])
                        alert = {"ts": time.time(), "url": c["url"], "platform": c["platform"],
                                 "evidence": ev.__dict__}
                        w["alerts"].append(alert); new.append(alert)
            except Exception:
                continue   # provider failure never stops monitoring
        if new:
            await self.notifier.notify("investigations",
                f"[{case_id}] {len(new)} new distribution point(s) found by monitoring.")
            if self.complaints and w["complaint_id"]:
                self.complaints.add_note(w["complaint_id"], "monitor",
                    f"{len(new)} new URL(s) auto-appended as supplementary evidence.")
        return new

    async def run_forever(self):
        while True:
            for case_id in list(self.watches):
                await self.sweep_once(case_id)
            await asyncio.sleep(self.interval)

    def start(self):
        self._task = asyncio.get_event_loop().create_task(self.run_forever())
