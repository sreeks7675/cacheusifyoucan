"""Person Monitoring — reverse deepfake search for an uploaded face.

Reuses main-app capabilities: the Semantic Agent's face embedder produces the
query embedding; providers search; matches are judged by the same
EvidenceMatcher. Output is an ExposureReport."""
from __future__ import annotations
import time
from dataclasses import dataclass, field, asdict

@dataclass
class ExposureReport:
    subject_id: str
    exposure_score: float           # 0..100
    total_matches: int = 0
    images: int = 0
    videos: int = 0
    deepfakes_detected: int = 0
    platforms: list[str] = field(default_factory=list)
    matches: list[dict] = field(default_factory=list)
    timeline: list[dict] = field(default_factory=list)
    risk_assessment: str = ""
    def to_dict(self): return asdict(self)

class PersonMonitor:
    def __init__(self, registry, matcher, face_embedder=None, deepfake_scorer=None):
        """face_embedder:   main app Semantic Agent (e.g. ArcFace/CLIP embed)
           deepfake_scorer: main app Forensic ensemble — reuse, don't retrain."""
        self.reg = registry
        self.matcher = matcher
        self.face_embedder = face_embedder
        self.deepfake_scorer = deepfake_scorer

    async def scan(self, subject_id: str, face_image: bytes = None) -> ExposureReport:
        emb = self.face_embedder(face_image) if (self.face_embedder and face_image) else None
        rep = ExposureReport(subject_id=subject_id, exposure_score=0)
        for provider in self.reg.search:
            try:
                cands = await provider.reverse_image(phash=None, clip_embedding=emb)
            except Exception:
                continue
            for c in cands:
                fake_p = None
                if self.deepfake_scorer and c.get("thumbnail_bytes"):
                    try: fake_p = float(self.deepfake_scorer(c["thumbnail_bytes"]))
                    except Exception: fake_p = None
                m = {"url": c["url"], "platform": c["platform"],
                     "media": "video" if "watch" in c["url"] else "image",
                     "first_seen": c.get("first_seen"), "fake_probability": fake_p}
                rep.matches.append(m)
                rep.total_matches += 1
                rep.videos += m["media"] == "video"; rep.images += m["media"] == "image"
                if (fake_p or 0) >= 0.5: rep.deepfakes_detected += 1
                if c["platform"] not in rep.platforms: rep.platforms.append(c["platform"])
                rep.timeline.append({"ts": c.get("first_seen"), "event": f'found on {c["platform"]}'})
        rep.exposure_score = min(100.0, rep.total_matches * 12 + rep.deepfakes_detected * 25)
        rep.risk_assessment = ("HIGH — synthetic media of subject in circulation"
                               if rep.deepfakes_detected else
                               "MODERATE — public appearances only" if rep.total_matches else
                               "LOW — no public matches")
        return rep
