"""RBAC data model — users, roles, permissions, sessions, audit."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
import time, uuid, hashlib, hmac, base64, json

PERMISSIONS = ["view", "create", "edit", "delete", "export", "download", "approve", "configure"]
MODULES = ["dashboard", "investigation", "planner_agent", "forensic_agent", "semantic_agent",
           "retrieval_agent", "evidence_fusion", "debate_agent", "decision_agent",
           "report_generation", "sentinel", "complaint_management", "user_management",
           "role_management", "audit_logs", "settings"]

def _matrix(level: str) -> dict:
    """Generate a module→permissions map from a coarse level."""
    full = {m: list(PERMISSIONS) for m in MODULES}
    if level == "all": return full
    if level == "admin":
        return {m: list(PERMISSIONS) for m in MODULES}
    if level == "manager":
        d = {m: ["view", "create", "edit", "export", "download", "approve"] for m in MODULES}
        for m in ("user_management", "role_management"): d[m] = ["view"]
        return d
    if level == "investigator":
        d = {m: ["view", "create", "edit", "export", "download"] for m in MODULES}
        for m in ("user_management", "role_management", "settings"): d[m] = []
        return d
    if level == "analyst":
        d = {m: ["view", "export", "download"] for m in MODULES}
        for m in ("user_management", "role_management", "settings", "complaint_management"): d[m] = []
        return d
    if level == "reviewer":
        d = {m: [] for m in MODULES}
        for m in ("investigation", "sentinel", "report_generation", "dashboard"):
            d[m] = ["view", "approve"]
        return d
    if level == "auditor":
        d = {m: ["view"] for m in MODULES}
        d["audit_logs"] = ["view", "export", "download"]
        return d
    return {m: (["view"] if m not in ("user_management", "role_management") else []) for m in MODULES}  # read_only

DEFAULT_ROLES = {
    "super_admin":          {"label": "Super Admin",           "perms": _matrix("all")},
    "administrator":        {"label": "Administrator",         "perms": _matrix("admin")},
    "investigation_manager":{"label": "Investigation Manager", "perms": _matrix("manager")},
    "investigator":         {"label": "Investigator",          "perms": _matrix("investigator")},
    "analyst":              {"label": "Analyst",               "perms": _matrix("analyst")},
    "human_reviewer":       {"label": "Human Reviewer",        "perms": _matrix("reviewer")},
    "auditor":              {"label": "Auditor",               "perms": _matrix("auditor")},
    "read_only":            {"label": "Read Only",             "perms": _matrix("read_only")},
}

@dataclass
class User:
    username: str
    password_hash: str
    role: str
    display_name: str = ""
    enabled: bool = True
    locked: bool = False
    failed_attempts: int = 0
    created_at: float = field(default_factory=time.time)
    login_history: list = field(default_factory=list)   # [{ts, ip, ok}]

@dataclass
class Session:
    token: str
    username: str
    role: str
    issued_at: float
    expires_at: float
    remember_me: bool = False

def hash_password(pw: str, salt: str = "truthlens") -> str:
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 100_000).hex()
