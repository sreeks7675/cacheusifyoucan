"""Evidence matching — the answer to "on what basis is it decided as fake?"

A crawled candidate is judged the SAME fake through three independent tests,
all inherited from the main app's already-computed knowledge:

  1. pHash Hamming distance  — pixel-level near-duplicate (Forensic Agent's hash)
  2. CLIP cosine similarity  — semantic same-scene (Semantic Agent's embedding)
  3. Generator fingerprint    — same synthesis toolchain (Forensic Agent's
                                latent-decoder signature, matched via the SAME
                                matcher / ChromaDB collection the main app uses)

Sentinel does NOT re-run deepfake detection on crawled images. The exhibit was
already ruled FAKE by the 7-agent pipeline; Sentinel only proves each crawled
item is a copy/variant of that exhibit. Verdict inheritance, not re-detection.
"""
from __future__ import annotations
from typing import Callable, Optional
from .schemas import MatchEvidence, SearchKeys

# thresholds (tune on the paired dataset)
PHASH_EXACT = 8        # ≤ 8/64 flipped bits → re-encoded copy
PHASH_VARIANT = 16     # ≤ 16 → cropped / re-composed variant
CLIP_SAME_SCENE = 0.90


def hamming(a: str, b: str) -> int:
    return bin(int(a, 16) ^ int(b, 16)).count("1")


def cosine(u: list[float], v: list[float]) -> float:
    num = sum(x * y for x, y in zip(u, v))
    du = sum(x * x for x in u) ** 0.5
    dv = sum(y * y for y in v) ** 0.5
    return num / (du * dv) if du and dv else 0.0


class EvidenceMatcher:
    """fingerprint_matcher is INJECTED from the main app so Sentinel literally
    reuses its training — e.g.:

        matcher = EvidenceMatcher(
            fingerprint_matcher=forensic_agent.match_generator_fingerprint,
            clip_embedder=semantic_agent.embed_image,   # optional, for candidates
        )

    If the callables are not provided, those tests are skipped (reported None),
    never guessed.
    """

    def __init__(self,
                 fingerprint_matcher: Optional[Callable[[bytes | str], bool]] = None,
                 clip_embedder: Optional[Callable[[bytes], list[float]]] = None):
        self.fingerprint_matcher = fingerprint_matcher
        self.clip_embedder = clip_embedder

    def judge(self, keys: SearchKeys, candidate: dict,
              method: str, provider: str, query_used: str) -> MatchEvidence:
        # 1) perceptual hash distance
        dist = None
        if keys.phash and candidate.get("thumb_phash"):
            dist = hamming(keys.phash, candidate["thumb_phash"])

        # 2) semantic similarity (embed candidate thumb if embedder available)
        cos = None
        if keys.clip_embedding and self.clip_embedder and candidate.get("thumbnail_bytes"):
            cand_emb = self.clip_embedder(candidate["thumbnail_bytes"])
            cos = round(cosine(keys.clip_embedding, cand_emb), 3)

        # 3) generator fingerprint — same toolchain as the exhibit?
        fp = None
        if self.fingerprint_matcher and candidate.get("thumbnail_bytes"):
            try:
                fp = bool(self.fingerprint_matcher(candidate["thumbnail_bytes"]))
            except Exception:
                fp = None  # matcher failure never breaks the workflow

        # classification from whatever evidence is available
        if dist is not None and dist <= PHASH_EXACT:
            cls = "exact_copy"
        elif (dist is not None and dist <= PHASH_VARIANT) or (cos or 0) >= CLIP_SAME_SCENE or fp:
            cls = "variant"
        else:
            cls = "unrelated"

        return MatchEvidence(
            method=method, provider=provider, query_used=query_used,
            phash_distance=dist, clip_cosine=cos, fingerprint_match=fp,
            classification=cls,
        )


def derive_search_keys(inv) -> SearchKeys:
    """Pull the main app's learned artifacts out of the investigation result."""
    fe = inv.forensic_evidence or {}
    return SearchKeys(
        phash=fe.get("phash"),
        clip_embedding=fe.get("clip_embedding"),
        generator_fingerprint=fe.get("generator_fingerprint"),
        generator_family=fe.get("generator_family"),
        entity_keywords=list(inv.extracted_entities or []),
    )
