"""Sentinel adapters — every external capability behind a swappable interface.

Business logic never talks to Google/Reddit/NCRP directly; it talks to these
base classes. Swap providers by registering a different implementation.
Real implementations go next to the mocks (e.g. GoogleImagesProvider using
SerpAPI, TelegramCrawler using Telethon) — same interface, zero pipeline edits.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Optional
import hashlib
import time
import uuid


# ------------------------------------------------------------ interfaces ---
class SearchProvider(ABC):
    """Reverse-image + keyword search on the open web."""
    name: str = "search"

    @abstractmethod
    async def reverse_image(self, phash: str, clip_embedding: Optional[list[float]]) -> list[dict]:
        """Return candidates: [{url, platform, handle, thumbnail_bytes|thumb_phash, first_seen, views, region}]"""

    @abstractmethod
    async def keyword(self, keywords: list[str]) -> list[dict]: ...


class CrawlerAdapter(ABC):
    """Platform-specific crawling (forums, messaging channels)."""
    name: str = "crawler"

    @abstractmethod
    async def crawl(self, keys) -> list[dict]: ...


class ThreatFeedProvider(ABC):
    """Reputation of extracted entities (domains, handles)."""
    name: str = "threatfeed"

    @abstractmethod
    async def lookup(self, entities: list[str]) -> list[dict]: ...


class CyberCrimeProvider(ABC):
    """Files the complaint. Returns an acknowledgment number."""
    name: str = "cybercrime"

    @abstractmethod
    async def file_complaint(self, package: dict) -> dict: ...


class NotificationProvider(ABC):
    @abstractmethod
    async def notify(self, channel: str, message: str) -> None: ...


# ---------------------------------------------------------------- mocks ----
# Deterministic demo data. Each mock documents what its REAL counterpart does.
class MockGoogleImagesProvider(SearchProvider):
    """Real version: SerpAPI / Bing Visual Search API — upload thumbnail or
    query by URL, get pages containing visually similar images."""
    name = "SearchProvider:google_images"

    async def reverse_image(self, phash, clip_embedding):
        return [
            {"url": "https://videosite.example/watch?v=x91", "platform": "Video platform",
             "handle": "@quick_finance_tips", "thumb_phash": _mutate(phash, bits=3),
             "first_seen": "2026-07-06", "views": "48.2K", "region": "IN"},
            {"url": "https://social.example/p/88231", "platform": "Social network",
             "handle": "@ceo.updates.official", "thumb_phash": _mutate(phash, bits=5),
             "first_seen": "2026-07-06", "views": "12.7K", "region": "IN"},
        ]

    async def keyword(self, keywords):
        return [
            {"url": "https://forum.example/board/vid/49221", "platform": "Forum mirror",
             "handle": "board/vid/49221", "thumb_phash": None,
             "first_seen": "2026-07-05", "views": None, "region": "US", "status": "removed"},
        ]


class MockTelegramCrawler(CrawlerAdapter):
    """Real version: Telethon session joining public channels from a watchlist,
    hashing every posted image and comparing against the search keys."""
    name = "CrawlerAdapter:telegram"

    async def crawl(self, keys):
        return [
            {"url": "https://t.me/insider_market_x/2231", "platform": "Messaging channel",
             "handle": "t.me/insider_market_x", "thumb_phash": _mutate(keys.phash, bits=6),
             "first_seen": "2026-07-07", "views": "8.9K", "region": "AE"},
        ]


class MockThreatFeed(ThreatFeedProvider):
    """Real version: VirusTotal / AbuseIPDB / PhishTank lookups."""
    name = "ThreatFeedProvider:virustotal+abuseipdb"

    async def lookup(self, entities):
        hits = []
        for e in entities:
            if "." in e:  # looks like a domain
                hits.append({"entity": e, "flagged_by": 3, "category": "payment-fraud infra"})
        return hits


class MockNCRPProvider(CyberCrimeProvider):
    """Real version: National Cybercrime Reporting Portal submission
    (or an official API/e-mail gateway where available)."""
    name = "CyberCrimeProvider:ncrp"

    async def file_complaint(self, package):
        ack = "NCRP-2026-" + hashlib.sha256(str(package).encode()).hexdigest()[:6].upper()
        return {"acknowledgment": ack, "filed_at": time.time(), "portal": "cybercrime.gov.in"}


class MockNotifier(NotificationProvider):
    async def notify(self, channel, message):
        print(f"[notify:{channel}] {message}")


def _mutate(phash: Optional[str], bits: int) -> Optional[str]:
    """Flip N bits of a hex phash — simulates a re-encoded copy of the image."""
    if not phash:
        return None
    v = int(phash, 16)
    for i in range(bits):
        v ^= 1 << ((i * 7) % 64)
    return f"{v:016x}"


# ------------------------------------------------------------- registry ----
class ProviderRegistry:
    """Plugin point. sentinel.analyze() only ever reads from here."""
    def __init__(self):
        self.search: list[SearchProvider] = [MockGoogleImagesProvider()]
        self.crawlers: list[CrawlerAdapter] = [MockTelegramCrawler()]
        self.threat_feed: ThreatFeedProvider = MockThreatFeed()
        self.cybercrime: CyberCrimeProvider = MockNCRPProvider()
        self.notifier: NotificationProvider = MockNotifier()

    def use(self, **kwargs) -> "ProviderRegistry":
        for k, v in kwargs.items():
            setattr(self, k, v)
        return self
