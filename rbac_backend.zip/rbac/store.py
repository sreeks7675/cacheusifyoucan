"""In-memory store + permission checks + audit log. Swap for a DB later —
interfaces stay identical."""
from __future__ import annotations
import time, uuid, copy
from .models import User, DEFAULT_ROLES, PERMISSIONS, MODULES, hash_password

class AuditLog:
    def __init__(self): self.entries = []
    def log(self, action, actor, detail=""):
        self.entries.append({"id": uuid.uuid4().hex[:8], "ts": time.time(),
                             "action": action, "actor": actor, "detail": detail})
    def query(self, action=None, actor=None):
        return [e for e in self.entries
                if (action is None or e["action"] == action)
                and (actor is None or e["actor"] == actor)]

class RbacStore:
    def __init__(self, audit: AuditLog):
        self.audit = audit
        self.roles = copy.deepcopy(DEFAULT_ROLES)
        self.users: dict[str, User] = {}
        self._seed()

    def _seed(self):
        for uname, pw, role, name in [
            ("admin", "Admin@123", "super_admin", "A. Sharma (Admin)"),
            ("investigator", "Invest@123", "investigator", "R. Verma"),
            ("analyst", "Analyst@123", "analyst", "S. Iyer"),
            ("reviewer", "Review@123", "human_reviewer", "K. Nair"),
            ("auditor", "Audit@123", "auditor", "M. Das"),
        ]:
            self.users[uname] = User(uname, hash_password(pw), role, name)

    # ---- user management (admin actions all audited) ----
    def create_user(self, actor, username, password, role, display_name=""):
        self.users[username] = User(username, hash_password(password), role, display_name)
        self.audit.log("user_created", actor, f"user={username} role={role}")
    def edit_user(self, actor, username, **kw):
        u = self.users[username]
        for k, v in kw.items(): setattr(u, k, v)
        self.audit.log("user_modified", actor, f"user={username} fields={list(kw)}")
    def delete_user(self, actor, username):
        self.users.pop(username, None)
        self.audit.log("user_deleted", actor, f"user={username}")
    def set_enabled(self, actor, username, enabled):
        self.users[username].enabled = enabled
        self.audit.log("user_modified", actor, f"user={username} enabled={enabled}")
    def set_locked(self, actor, username, locked):
        self.users[username].locked = locked
        self.audit.log("account_locked" if locked else "account_unlocked", actor, f"user={username}")

    # ---- role management ----
    def create_role(self, actor, key, label, perms):
        self.roles[key] = {"label": label, "perms": perms}
        self.audit.log("role_created", actor, f"role={key}")
    def clone_role(self, actor, src, key, label):
        self.roles[key] = {"label": label, "perms": copy.deepcopy(self.roles[src]["perms"])}
        self.audit.log("role_created", actor, f"role={key} cloned_from={src}")
    def set_permission(self, actor, role, module, perm, granted):
        perms = self.roles[role]["perms"].setdefault(module, [])
        if granted and perm not in perms: perms.append(perm)
        if not granted and perm in perms: perms.remove(perm)
        self.audit.log("permission_changed", actor, f"role={role} {module}.{perm}={granted}")

    # ---- the check every endpoint calls ----
    def can(self, username_or_role: str, module: str, perm: str) -> bool:
        role = username_or_role
        if username_or_role in self.users:
            u = self.users[username_or_role]
            if not u.enabled or u.locked: return False
            role = u.role
        return perm in self.roles.get(role, {}).get("perms", {}).get(module, [])

def require(store: RbacStore, module: str, perm: str):
    """Decorator/dependency for FastAPI-style endpoints:
        @app.get("/reports")
        @require(store, "report_generation", "view")
        def endpoint(user=...): ...
    """
    def deco(fn):
        def wrapper(*a, user: str = None, **kw):
            if not user or not store.can(user, module, perm):
                store.audit.log("access_denied", user or "anonymous", f"{module}.{perm}")
                raise PermissionError(f"{module}.{perm} denied")
            return fn(*a, user=user, **kw)
        return wrapper
    return deco
